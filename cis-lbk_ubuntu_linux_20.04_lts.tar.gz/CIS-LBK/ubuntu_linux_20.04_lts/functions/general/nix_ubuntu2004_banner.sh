BANR()
{
	echo ""
	echo ""
	echo "     ######################################################## "
	echo "     #  CIS Linux Build Kit for Ubuntu Linux 20.04 LTS      # "
	echo "     #  This Linux Build Kit works in conjunction with the  # "
	echo "     #  CIS Ubuntu Linux 20.04 LTS Benchmark v1.1.0         # "
	echo "     #  This script is the property of:                     # "
	echo "     #  Center for Internet Security (CIS)                  # "
	echo "     ######################################################## "
	echo ""
	echo ""
}
# End of print bannor to Screen